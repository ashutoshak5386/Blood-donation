<?php
include('header.php');
include('nav.php'); ?>

<!DOCTYPE html>
<html lang="en" dir="ltr">

<head>

    <title>Blood Donation | Welcome</title>

    <section id="boxes" align="center">
        <div class="container" align="center">
            <div class="box">
                <img src="admin.png" ALT="Admin Login" WIDTH=100 HEIGHT=100>
                <ul style="list-style:none;">
                    <li><a href="loginadmin.php">Admin Login</a></li>
                </ul>
                <br></br>
            </div>
            <div class="box">
                <img src="user.png" ALT="User Login" WIDTH=140 HEIGHT=100>
                <ul style="list-style:none;">
                    <li><a href="loginuser.php">User Login</a></li>
                </ul>
                <br></br>
            </div>
        </div>
    </section>
    </body>

</html>
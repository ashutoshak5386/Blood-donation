# Blood donation 
Small project done using
HTML, CSS, JS, PHP and MYSQL.
It is hosted using cpanel, link is given below:
http://blooddo.epizy.com/

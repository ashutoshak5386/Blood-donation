<!DOCTYPE html>
<html lang="en" dir="ltr">

<head>

  <title>Blood Donation | Welcome</title>
  <link rel="stylesheet" href="style.css">
</head>

<body>
  <header>
    <h1><img src="request.png" alt="" WIDTH=40 HEIGHT=50 /> Blood Donation</h1>

  </header>


</body>

</html>
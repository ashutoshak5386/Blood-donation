<!DOCTYPE html>
<html>

<head>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="nav.css">
</head>

<body>

  <div class="navbar">
    <a href="contact.php">Contact</a>
    <a href="about.php">About</a>
    <a href="index.php">Home</a>
  </div>
  <div class="image">
    <img src="bg.jpg" alt="" WIDTH=1350 HEIGHT=500 />
  </div>
</body>

</html>
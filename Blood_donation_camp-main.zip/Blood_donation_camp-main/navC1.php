<!DOCTYPE html>
<html>

<head>
  <script src="https://kit.fontawesome.com/4cd457a180.js" crossorigin="anonymous"></script>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="nav.css">
</head>

<body>

  <div class="navbar">
    <a href="logout.php"><i class="fa fa-sign-out"></i></a>
    <a href="contact.php">Contact</a>
    <a href="about.php">About</a>
    <a href="index.php">Home</a>
  </div>
</body>

</html>
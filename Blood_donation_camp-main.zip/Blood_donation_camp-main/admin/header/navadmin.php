<!DOCTYPE html>
<html>

<head>
  <script src="https://kit.fontawesome.com/4cd457a180.js" crossorigin="anonymous"></script>
  <link rel="stylesheet" href="./css/nav.css">
</head>

<body>

  <div class="navbar">
    <a href="logout.php"><i class="fa fa-sign-out"></i></a>
    <a href="about.php">About</a>
    <a href="donationlist.php">Donation List</a>
    <a href="index.php">Home</a>

  </div>
  <div class="image">
    <img src="img/bg.jpg" alt="" WIDTH=1350 HEIGHT=500 />
  </div>
</body>

</html>